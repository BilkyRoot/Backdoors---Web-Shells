# Web-Shells
Some of the best web shells that you might need for web hacking!


| Name | Link |
|--|--|
| Alfa3 | [Find Here!](https://github.com/TheBinitGhimire/Web-Shells/blob/master/alfa3.php) |
| Alfa3.0.1 | [Find Here!](https://github.com/TheBinitGhimire/Web-Shells/blob/master/alfav3.0.1.php) |
| Andela | [Find Here!](https://github.com/TheBinitGhimire/Web-Shells/blob/master/andela.php) |
| BloodSecV4 | [Find Here!](https://github.com/TheBinitGhimire/Web-Shells/blob/master/bloodsecv4.php) |
| By | [Find Here!](https://github.com/TheBinitGhimire/Web-Shells/blob/master/by.php) |
| C99 | [Find Here!](https://github.com/TheBinitGhimire/Web-Shells/blob/master/c99ud.php) |
| CMD | [Find Here!](https://github.com/TheBinitGhimire/Web-Shells/blob/master/cmd.php) |
| Configuration File Killer | [Find Here!](https://github.com/TheBinitGhimire/Web-Shells/blob/master/configkillerionkros.php) |
| JSP  Shell | [Find Here!](https://github.com/TheBinitGhimire/Web-Shells/blob/master/jspshell.jsp) |
| Mini Shell | [Find Here!](https://github.com/TheBinitGhimire/Web-Shells/blob/master/mini.php) |
| Obfuscated Punk | [Find Here!](https://github.com/TheBinitGhimire/Web-Shells/blob/master/obfuscated-punknopass.php) |
| Punk no Password | [Find Here!](https://github.com/TheBinitGhimire/Web-Shells/blob/master/punk-nopass.php) |
| Punkholic | [Find Here!](https://github.com/TheBinitGhimire/Web-Shells/blob/master/punkholic.php) |
| R57 | [Find Here!](https://github.com/TheBinitGhimire/Web-Shells/blob/master/r57.php) |
| Smevk | [Find Here!](https://github.com/TheBinitGhimire/Web-Shells/blob/master/smevk.php) |
| WSO | [Find Here!](https://github.com/TheBinitGhimire/Web-Shells/blob/master/wso2.8.5.php) |
